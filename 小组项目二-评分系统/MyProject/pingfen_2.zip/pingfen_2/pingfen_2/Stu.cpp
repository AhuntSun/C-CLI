#include "stdafx.h"
#include "Stu.h"


Stu::Stu()
{
	fScore = gcnew array<float>(7);
	strName = gcnew array<String^>(4);
	gScore = gcnew array<float>(4);
	/*
	Score = 0;
	strName = nullptr;*/
}
